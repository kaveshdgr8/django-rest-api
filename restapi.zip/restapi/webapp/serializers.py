from rest_framework import serializers
from rest_framework import users

class usersSerializer(Serializers.Modelserializer):

    class Meta:
        model=users
        fields='__all__'
