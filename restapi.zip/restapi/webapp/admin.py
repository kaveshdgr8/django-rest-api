from django.contrib import admin
from .models import users

admin.site.register(users)
# Register your models here.
